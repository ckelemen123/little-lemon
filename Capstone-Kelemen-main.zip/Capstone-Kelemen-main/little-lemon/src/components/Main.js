import React from 'react';

const Main = () => {
    return (
        <main>
            <p> This is the firt text.</p>
            <p> This is the next set of text.</p>
        </main>
    );
}

export default Main;